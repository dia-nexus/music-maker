# 音楽づくりの道具（tools/music）

公開版（どこでもスキルとして入るもの、MIT）は https://github.com/dia-nexus/music-maker 。こちらを直したら `python3 tools/music/pack-skill.py` で dist/music-maker（Claude Code 用）と dist/music-maker-chat.zip（claude.ai のチャット用）を作り、前者の中身と後者の zip（公開版の chat/music-maker.zip）を公開版に写す。

動画の BGM や効果音を、Claude が設計図から作るための道具。設計図（YAML/JSON）を渡すと、作曲して MIDI を書き、SoundFont の生楽器に近い音で鳴らし、ミックスして、数値と図の報告まで出す。Claude は音を聴けないので、報告の数値と図が耳の代わりになる。いつ・どう使うかは `.claude/skills/music-maker/SKILL.md` に書いてあり、ほかのセッションはそれを読めば使える。

## 使い方

```bash
python3 tools/music/music.py setup                                   # セッションごとに1回。FluidSynth と GeneralUser GS を入れる
python3 tools/music/music.py make tools/music/examples/promo-60s.yaml -o out/promo
python3 tools/music/music.py serve                                   # 人が使う編集画面 http://127.0.0.1:8765/
```

ほかのコマンドは `doctor`（どの音源で鳴るか）、`styles`（様式の一覧）、`new --style lofi --seconds 30`（設計図のひな形）、`compose`（MIDI と作曲の記録だけ、0.2 秒）。`make` には `--seed N`（別の案）、`--synth`（SoundFont を使わず合成音）、`--no-stems` が付けられる。

`out/promo/` には `master.wav`（48kHz/24bit）、`music.mid`、`stems/`、`preview.mp3`、`report.md`・`report.html`・`report.json`、`images/`（スペクトログラム、ピアノロール、音量の推移、小節どうしの似かよい）ができる。`examples/promo-60s/` に、例の設計図から作った報告と試聴用の mp3 を置いてある（WAV と stems は大きいので入れていない）。

## 様式

| 様式 | 名前 | テンポ・調の既定 |
|---|---|---|
| `bright_pop` | 明るいポップ | 120・D major |
| `acoustic` | やわらかいアコースティック | 92・G major |
| `cinematic` | 映画風オーケストラ | 100・D minor |
| `lofi` | ローファイ | 78・F major（跳ね） |
| `playful` | 遊び心（ピチカートと木管） | 126・F major |

## 音源

上から順に、見つかったもので鳴らす。鳴らす道具は FluidSynth、apt が使えない所では pip の tinysoundfont（`MUSIC_MAKER_ENGINE=tinysoundfont` で手元でも試せる）。

1. 環境変数 `MUSIC_SF2` の SoundFont
2. `tools/music/.cache/GeneralUser-GS.sf2`（setup が raw.githubusercontent.com から取る。v2.0.3、約31MB。許諾は自作の曲への利用に制限なし、同梱・改変も可）
3. `/usr/share/sounds/sf2/FluidR3_GM.sf2`（apt の fluid-soundfont-gm、MIT）
4. GitHub に届かないとき：npm の registry の GeneralUser GS 1.47、それも無理なら pip の pretty_midi に入っている TimGM6mb（チャットの既定のネットワークは pip・npm などにしか出られないため）
5. どれも無ければ `mm/synth.py` の合成音（サンプルを使わない。弦は鋸歯の合奏と胴の共鳴、ギターは Karplus-Strong など）

ピアノだけは Salamander Grand Piano（CC-BY 3.0、落とすのは約300MB、展開後 1.27GB）に差し替えられる。`python3 tools/music/music.py setup --extra salamander` で `.cache/` に取り、ある間はピアノの楽器がそれで鳴る。曲を外に出すときはクレジット（Salamander Grand Piano V3 by Alexander Holm, CC-BY 3.0）を添える。取得の経路と、ほかの音源の許諾の調べは `docs/sound-sources.md`。

SoundFont を git に入れていないのは、32MB の SoundFont を入れるとこのリポジトリを clone するすべてのセッションが毎回それを落とすことになるから。setup で取れば数秒で済む。

## 構成

| ファイル | 中身 |
|---|---|
| `music.py` | 入口。setup / doctor / styles / new / compose / make / serve |
| `mm/spec.py` | 設計図を読み、秒・小節・拍の書き方をそろえ、テンポの地図（rit. を含む）を作る |
| `mm/theory.py` | 調、ローマ数字の和音、声部の進め方（平行5度・8度を避け、動きの少ない配置）、和音名の推定 |
| `mm/styles.py` | 楽器の一覧（GM の番号・音域・定位・系統）、様式のひな形、和声進行の手持ち、終止の形。数を変えるならここ |
| `mm/compose.py` | 作曲。和声→旋律（動機と展開。平歌・盛り上げ・山場の2回め以降は1回めを繰り返す）→伴奏の型→きっかけ→終止→強弱→同じ小節の解消→弾き方（つなぐ・ペダル・拍と句の強弱・伴奏を弱く）→人間らしい揺れ |
| `mm/midi.py` | MIDI の書き出し（全体と楽器ごと） |
| `mm/render.py` | FluidSynth で楽器ごとに書き出す（並列）。無ければ合成音 |
| `mm/synth.py` | SoundFont が無いときの合成音 |
| `mm/sfx.py` | 楽器で出せない効果音（風切り、上昇、低い衝撃、逆再生シンバル、打音、針音） |
| `mm/mix.py` | 楽器ごとの音量合わせ・EQ・圧縮（打つ楽器は当たりを丸める）・残響（数値で作った部屋の響きを畳み込む）・広がり、全体の圧縮・ラウドネス・真のピーク |
| `mm/check.py` | 確かめの報告（数値と図。弾き方の目安：旋律のつながり・ペダル・打鍵の強さ・ベースの同音連打・刺さる高域の割合） |
| `editor.html` | 人が使う編集画面。`serve` で開くと作る・聴くまでできる |
| `impact.rules.cjs` | 一緒に直すべき箇所の照合（様式・きっかけ・役割・楽器の系統・伴奏の型） |

決めたことと理由、分かっている限界、次にやることは `docs/design.md`。

## 開発と検証

```bash
python3 -m unittest discover -s tools/music/tests               # 21 本、10 秒
python3 tools/music/music.py serve --port 8765 &                # 編集画面の自動テストプレイ（PC とスマホ幅）
NODE_PATH=$(npm root -g) node tools/music/tests/editor.playthrough.cjs out/editor-shots
node scripts/impact.cjs check                                   # 連動の照合
```

道具を直したら、例の設計図で `make` を流し、`examples/promo-60s/` の報告を書き直してコミットする（報告の数字が今の道具の結果と食い違わないように）。
